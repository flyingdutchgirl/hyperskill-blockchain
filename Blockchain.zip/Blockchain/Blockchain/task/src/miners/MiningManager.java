package miners;

import blockchain.Block;
import blockchain.BlockChain;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MiningManager implements Runnable {

    private volatile int blocksGenerated;
    private int blocksToGenerate;
    private ArrayList<Block> ourBlocks;
    private ArrayList<Miner> ourMiners;
    private BlockChain blockChain;

    public ExecutorService getExecutor() {
        return executor;
    }

    private ExecutorService executor;
    private int numberOfMiners;

    public MiningManager(BlockChain blockChain, int target) {
        this.blocksGenerated = 0;
        this.blocksToGenerate = target;
        this.ourBlocks = new ArrayList<>();
        this.ourMiners = new ArrayList<>();
        this.blockChain = blockChain;
        this.numberOfMiners = 4;
        this.executor = Executors.newFixedThreadPool(this.numberOfMiners);
    }


    public void work() {
        for (int i = 0; i < numberOfMiners; i++) {
            ourMiners.add(new Miner(blockChain, this, i));
        }

        for (Miner miner: ourMiners) {
            executor.submit(miner);
        }



        executor.shutdown();
        try {
            executor.awaitTermination(60, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    synchronized boolean blockGenerated(Block block) {
        blocksGenerated++;
        ourBlocks.add(block);

        boolean isFinished = isTargetReached();
        if (isFinished) {
            executor.shutdownNow();
        }

        return isFinished;
    }

    synchronized boolean isTargetReached() {
        return blocksGenerated >= blocksToGenerate;
    }

    @Override
    public void run() {
        work();
    }
}
