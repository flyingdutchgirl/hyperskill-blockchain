package miners;

import blockchain.Block;
import blockchain.BlockChain;

public class Miner implements Runnable {

    private BlockChain bc;
    private MiningManager manager;
    private int minerId;

    public Miner(BlockChain blockChain, MiningManager manager, int minerId) {
        this.bc = blockChain;
        this.manager = manager;
        this.minerId = minerId;
    }

    @Override
    public void run() {
        while (!manager.isTargetReached()) {
            Block bl = generateNewBlock();
            manager.blockGenerated(bl);
        }
    }


    private Block generateNewBlock() {
        Block bl;

        do {
            bl = new Block("", bc.getPreviousId() + 1,
                    bc.getPreviousHash(), bc.getN(), minerId);
        } while (!bc.validate(bl));

        return bl;
    }

}
