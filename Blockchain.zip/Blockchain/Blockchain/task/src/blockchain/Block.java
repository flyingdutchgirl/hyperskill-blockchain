package blockchain;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.Date;
import java.util.Random;

public class Block implements Serializable {

    private String content;
    private int id;
    private int minerId;
    private int magic;
    private String previousHash;
    private String myHash;
    private long timeStamp;
    private long generationTime;


    public Block(String content, int id, String previousHash, int requiredZeros, int minerId) {
        this.content = content;
        this.id = id;
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.minerId = minerId;
        generateHash(requiredZeros);
    }


    private void generateHash(int zeros) {
        Random rand = new Random();
        long startTime = System.currentTimeMillis();
        long attempts = 0;

        do {
            attempts++;
            magic = rand.nextInt();
            String info = getHashableContent();
            myHash = StringUtil.applySha256(info);
        } while (!StringUtil.startsWithZeros(this.myHash, zeros));

        //System.out.println("zeros = " + zeros + "  attempts = " + attempts);

        generationTime = System.currentTimeMillis() - startTime;
    }


    public String getHashableContent() {
        return magic + content + id + previousHash + timeStamp + minerId;
    }

    @Override
    public String toString() {
        return "Block: " + content + "\n"
                + "Created by miner # " + minerId
                + "\nId: " + id
                + "\nTimestamp: " + timeStamp +
                "\nMagic number: " + magic +
                "\nHash of the previous block:\n"
                + previousHash + "\nHash of the block:\n" + myHash + "\n";
    }

    public String generationTimeString() {
        return "Block was generating for " + getGenerationTimeSeconds() + " seconds";
    }

    public int getGenerationTimeSeconds() {
        return (int) generationTime / 1000;
    }

    public int getMinerId() {
        return minerId;
    }

    public String getContent() {
        return content;
    }

    public int getId() {
        return id;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public String getMyHash() {
        return myHash;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

}
