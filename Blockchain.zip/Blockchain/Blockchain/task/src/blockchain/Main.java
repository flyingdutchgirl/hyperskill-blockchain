package blockchain;

import miners.MiningManager;

import java.io.Serializable;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        BlockChain chain = new BlockChain();

        chain = BlockChain.readFromFile();

        final int TARGET = 5;


        MiningManager manager = new MiningManager(chain, TARGET);
        Thread threadManager = new Thread(manager);
        threadManager.start();
        threadManager.join();

        manager.getExecutor().shutdownNow();
        threadManager.interrupt();
        BlockChain.saveToFile(chain);

    }
}
