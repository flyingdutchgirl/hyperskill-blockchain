package blockchain;

import java.io.*;
import java.util.ArrayList;
import java.util.function.Function;

public class BlockChain implements Serializable {
    private ArrayList<Block> blocks;
    private int previousId;
    private String previousHash;
    private int n;
    private Function<BlockChain, Boolean> stopCondition;


    public BlockChain() {
        this.blocks = new ArrayList<>();
        this.previousId = 0;
        this.previousHash = "0";
        this.n = 0;
    }


    public synchronized boolean validate(Block bl) {
//        if (stopCondition.apply(this)) {
//            return false;
//        }

        if (bl.getPreviousHash().equals(this.previousHash)
                && bl.getId() == previousId + 1
                && StringUtil.startsWithZeros(bl.getMyHash(), this.n))
        {
            this.blocks.add(bl);
            this.previousHash = bl.getMyHash();
            this.previousId += 1;

            System.out.println(bl.toString());
            System.out.println(bl.generationTimeString());
            int generationTime = bl.getGenerationTimeSeconds();


            if (generationTime < 4) {
                System.out.println("N was increased to " + (++n));
            } else if (generationTime > 60) {
                System.out.println("N was decreased to " + (--n));
            }
            System.out.println();

            return true;
        }

        return false;
    }

    public synchronized int getPreviousId() {
        return previousId;
    }

    public synchronized String getPreviousHash() {
        return previousHash;
    }

    public synchronized int getN() {
        return n;
    }

    public synchronized Function<BlockChain, Boolean> getStopCondition() {
        return stopCondition;
    }

    synchronized void setStopCondition(Function<BlockChain, Boolean> stopCondition) {
        this.stopCondition = stopCondition;
    }

    public synchronized boolean isStopCondition() {
        return stopCondition.apply(this);
    }

    public static void saveToFile(BlockChain blockChain) {
        File file = new File("my_blockchain.txt");
        try {
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(blockChain);
            oos.close();
            System.out.println("Succesfully saved!");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static BlockChain readFromFile() {
        File file = new File("my_blockchain.txt");
        BlockChain blockChain = null;

        try {
            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Object obj = ois.readObject();
            blockChain = (BlockChain) obj;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return blockChain;
    }

    /*
       public Block[] generate(int howMany, int zeros) {
        Block[] arr = new Block[howMany];
        for (int i = 0; i < howMany; i++) {
            Block bl = new Block("", ++previousId, previousHash, zeros);
            previousHash = bl.getMyHash();
            arr[i] = bl;
            blocks.add(bl);
        }

        return arr;
    }

    */



}
